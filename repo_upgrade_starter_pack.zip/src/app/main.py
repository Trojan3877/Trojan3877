from fastapi import FastAPI, UploadFile, File
from prometheus_client import Counter, generate_latest, CONTENT_TYPE_LATEST
from starlette.responses import Response

app = FastAPI(title="Demo Inference API")

REQUESTS = Counter("app_requests_total", "Total requests", ["endpoint"])

@app.get("/health")
def health():
    REQUESTS.labels(endpoint="/health").inc()
    return {"status": "ok"}

@app.get("/metrics")
def metrics():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    REQUESTS.labels(endpoint="/predict").inc()
    # TODO: load model and run inference here
    return {"prediction": "neutral", "confidence": 0.50}
