import argparse, time, random
def main(smoke: bool = False):
    time.sleep(0.5 if smoke else 2.0)
    metrics = {
        "auc": round(random.uniform(0.7, 0.9), 3),
        "f1": round(random.uniform(0.6, 0.85), 3),
        "latency_ms": round(random.uniform(20, 60), 1),
    }
    print("METRICS:", metrics)
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke", type=int, default=0)
    args = parser.parse_args()
    main(smoke=bool(args.smoke))
