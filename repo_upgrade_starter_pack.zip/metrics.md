# Metrics & Evaluation

- **Dataset**: describe source & size
- **Protocol**: train/val/test split, cross-validation, seeds
- **Metrics**: e.g., AUC, F1, accuracy, latency (p50/p95), throughput
- **Artifacts**: link to `/models/`, `/reports/`, or MLflow run

Example CLI:
```bash
python scripts/eval.py --smoke 1
```
